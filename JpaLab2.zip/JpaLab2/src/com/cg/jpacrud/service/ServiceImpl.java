package com.cg.jpacrud.service;

import java.util.List;

import com.cg.entities.Author;
import com.cg.entities.Book;
import com.cg.jpacrud.dao.Dao;
import com.cg.jpacrud.dao.DaoImpl;

public class ServiceImpl implements Service {

	Dao dao;
	List bookList;
	Book book;
	List authorList;
	
	public ServiceImpl() {
      dao= new DaoImpl();
	}

	@Override
	public List getAllBooks() {
 
		bookList=dao.getAllBooks();
		return bookList;
	}

	@Override
	public List getBooksByAuthorName(String authorName) {

		bookList=dao.getBooksByAuthorName(authorName);
		return bookList;
	}

	@Override
	public List getBooksByPriceRange() {

		bookList=dao.getBooksByPriceRange();
		return bookList;
	}

	@Override
	public List fetchAuthorsByBookId(int bookId) {

		authorList=dao.fetchAuthorsByBookId(bookId);
		return authorList;
	}

	@Override
	public void addAuthor(Author author) {
		
		dao.addAuthor(author);
		
	}
	
	

}
