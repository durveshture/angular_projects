package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;

import com.cg.entities.Author;
import com.cg.entities.Book;


public class DaoImpl implements Dao {

	private EntityManager entityManager;
	List bookList;
	List authorList;
	Book book;
	Author author;

	public DaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public List getAllBooks() {

		bookList= entityManager.createQuery("SELECT book from Book book", Book.class).getResultList();
		return bookList;
	}

	@Override
	public List getBooksByAuthorName(String authorName) {

		author= entityManager.createQuery("SELECT author from Author author WHERE author.name=:authorName", Author.class).setParameter("authorName", authorName).getSingleResult();
		bookList=author.getBooks();
//		book=(Book) bookList.get(0);
	
		return bookList;
	}

	@Override
	public List getBooksByPriceRange() {
		bookList= entityManager.createQuery("SELECT book from Book book WHERE book.price between 500 and 1000", Book.class).getResultList();
		return bookList;
	}

	@Override
	public List fetchAuthorsByBookId(int bookId) {
 
		book=entityManager.createQuery("SELECT book from Book book WHERE book.ISBN=:bookId", Book.class).setParameter("bookId", bookId).getSingleResult();		
		authorList= book.getAuthors();
		
		return authorList;
	}

	@Override
	public void addAuthor(Author author) {

		entityManager.persist(author);
	}

	

	
	
	
}
