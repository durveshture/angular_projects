package com.cg.test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import com.cg.entities.Author;
import com.cg.entities.Book;
import com.cg.jpacrud.dao.JPAUtil;
import com.cg.jpacrud.service.Service;
import com.cg.jpacrud.service.ServiceImpl;


public class Test {

	private static EntityManager mgr;
	Service service;

	@BeforeClass
	public static void init() {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		mgr = factory.createEntityManager();
//		mgr=JPAUtil.getEntityManager();
				
	}

	@Before
	public void start() {
		service= new ServiceImpl();
		mgr.getTransaction().commit();
	}
	
	@org.junit.Test
	public void testAdd(){
		
		List<Book> bookList= new ArrayList<Book>();  
		Book b1= new Book();
		b1.setISBN(1);
		b1.setTitle("harry potter and order of phoenix");
		b1.setPrice(100);
		bookList.add(b1);
		
		Book b2= new Book();
		b1.setISBN(2);
		b1.setTitle("harry potter and goblet of fire");
		b1.setPrice(290);
		bookList.add(b2);
		
		Author author= new Author();
		author.setID(100);
		author.setName("J.K Rowling");
		author.setBooks(bookList);
		mgr.persist(author);
	}
	
	@org.junit.Test
	public void testFetchAllBooks(){
		List<Book> bookList= new ArrayList<Book>();
		bookList= service.getAllBooks();
		
		for(Book book:bookList){
			System.out.println(book);
		}
	}
	
	@After
	public void stop(){
		mgr.getTransaction().commit();
	}
	
	@AfterClass
	public void flush(){
		mgr.close();
	}

}
