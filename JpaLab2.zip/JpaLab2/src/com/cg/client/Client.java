package com.cg.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Author;
import com.cg.entities.Book;
import com.cg.jpacrud.service.Service;
import com.cg.jpacrud.service.ServiceImpl;

public class Client {

	public static void main(String[] args) {
		EntityManager mgr;
		Service service;
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		mgr = factory.createEntityManager();
		service = new ServiceImpl();
		List<Author> authorList = new ArrayList<>();
		List<Book> bookList = new ArrayList<>();
		String authorName;
		int bookId;
		Scanner sc = new Scanner(System.in);

		for (;;) {
			System.out.println("Enter a choice");
			System.out
					.println("1) Fetch All Books \n 2) Fetch Books By Author Name \n 3) Fetch Books By price range \n 4) Search Author by Book id \n 5)Add Author \n 6) Exit");

			Scanner scan = new Scanner(System.in);
			String choice = scan.next();

			switch (choice) {
			case "1":
				bookList = service.getAllBooks();
				System.out.println(bookList);

				break;
			case "2":
				System.out.println("Enter author name");
				authorName = sc.next();
				bookList = service.getBooksByAuthorName(authorName);
				System.out.println(bookList);
				break;
			case "3":
				bookList = service.getBooksByPriceRange();
				System.out.println(bookList);
				break;
			case "4":
				System.out.println("Enter book id: ");
				bookId = sc.nextInt();
				authorList = service.fetchAuthorsByBookId(bookId);
				System.out.println(authorList);
				break;
			case "5":
				Book b1 = new Book();
				b1.setISBN(1);
				b1.setTitle("harry potter and order of phoenix");
				b1.setPrice(100);

				Book b2 = new Book();
				b2.setISBN(2);
				b2.setTitle("harry potter and goblet of fire");
				b2.setPrice(290);

				Book b3 = new Book();
				b3.setISBN(2);
				b3.setTitle("harry potter and the deathly hallows");
				b3.setPrice(900);

				Author author1 = new Author();
				author1.setID(100);
				author1.setName("J.K Rowling");
				author1.addBook(b1);
				author1.addBook(b2);
				author1.addBook(b3);
				mgr.getTransaction().begin();
				mgr.merge(author1);
				mgr.getTransaction().commit();
				break;
			case "6":
				System.exit(0);
				break;
			default:
				break;
			}
		}
	}
}
