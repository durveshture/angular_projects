package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="")
public class Album {

}
