package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Employee;
import com.cg.repo.EmployeeRepo;

@Repository
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo repo;
	
	//saving employee in the database
	@Override
	public Employee saveEmployee(Employee employee) {
		int id= employee.getEmpid();
		
		//check if employee exists for the id, if yes then insert employee details, if no then give a message to user
		if(repo.existsById(id)) {
			System.out.println("Employee already exist for employee id: "+id);
			return null;
		}
		else {
			repo.save(employee);	
			System.out.println("Employee details inserted for employee id: "+id);
			return employee;
			
		}
	}

	//fetching employee from db by id
	@Override
	public Employee getEmployeeById(int id) {
		return repo.findById(id).get();
	}

	//fetching all employees from db
	@Override
	public Iterable<Employee> getAllEmployees() {
		return repo.findAll();
	}

	//deleting employee from database by id 
	@Override
	public String deleteEmployee(int id) {
		//check if employee exists for the id, if yes then delete employee, if no then give a message to user
		if(repo.existsById(id)) {
		repo.deleteById(id);
		return "DELETED SUCCESSFULLY";
		}
		else {
			return "No employee found with this id";
		}
		
	}

	//updating employee from database 
	@Override
	public Employee updateEmployee(Employee employee) {
		int id= employee.getEmpid();
	
		//check if employee exists for the id, if yes then update employee details, if no then give a message to user
		if(repo.existsById(id)) {
			repo.save(employee);	
			System.out.println("Employee details updated for employee id: "+id);
			return employee;
		}
		else {
			System.out.println("Employee does not exist for employee id: "+id);
			return null;
		}
		
	}

	//fetching employee from db by name
	@Override
	public Iterable<Employee> findEmployeeByName(String name) {
		return  repo.findByDeptname(name);
	}

}
