package com.cg.service;

import com.cg.entity.Employee;

public interface EmployeeService {

	Employee saveEmployee(Employee employee);
	
	Employee getEmployeeById(int id);
	
	Iterable<Employee> getAllEmployees();
	
	String deleteEmployee(int id);
	
	Employee updateEmployee(Employee employee);
	
	Iterable<Employee> findEmployeeByName(String name);
}
