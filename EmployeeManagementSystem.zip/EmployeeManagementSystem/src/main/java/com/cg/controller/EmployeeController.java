package com.cg.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Employee;
import com.cg.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	//getting employee id through params and fetching employee of the respective id 
	@GetMapping(path = "/getbyid", produces = "application/json")
	public ResponseEntity<Employee> getEmployeeById(@RequestParam("id") int id) {
		try {
			Employee employee = service.getEmployeeById(id);
			return new ResponseEntity<Employee>(employee, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity("Employee id not found", HttpStatus.NOT_FOUND);
		}
	}

	//getting department name through url path variable and fetching employees of respective department 
	@GetMapping(path = "/employees/{deptName}")
	public Iterable<Employee> getEmployeeByDeptName(@PathVariable String deptName) {
	
			return service.findEmployeeByName(deptName);
		
	}

	//fetching all employees
	@GetMapping(path = "/employees")
	public Iterable<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

	//getting employee details through request body and inserting the employee details
	@PostMapping(path = "/addemployee", consumes = "application/json")
	public Employee insertEmployee(@RequestBody Employee employee) {
		return service.saveEmployee(employee);
	}

	//getting employee id through url path variable and deleting that employee
	@DeleteMapping("/deleteemployee/{id}")
	public String deleteEmployee(@PathVariable int id) { // @RequestParam("id") int id) {

		return service.deleteEmployee(id);

	}

	//getting employee details through request body and updating the employee details
	@PutMapping("/updateemployee")
	public Employee updateEmployee(@RequestBody Employee employee) {
		return service.updateEmployee(employee);
	}
}
