package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Employee;

public interface EmployeeRepo extends CrudRepository<Employee, Integer> {

	Iterable<Employee> findByDeptname(String name);
}
