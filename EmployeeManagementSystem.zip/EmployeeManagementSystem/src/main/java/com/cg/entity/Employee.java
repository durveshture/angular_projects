package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {

	//database field values
	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "employeeId")
//	@SequenceGenerator(sequenceName = "cust_seq", name = "employeeId")
	@GeneratedValue
	@Column(length=20)
	private int empid;
	
	@Column(length=20)
	private String name;
	
	@Column(length=20)
	private String designation;
	
	private int salary;
	
	@Column(length=25)
	private String deptname;

	
	//getters and setters

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
	
}
