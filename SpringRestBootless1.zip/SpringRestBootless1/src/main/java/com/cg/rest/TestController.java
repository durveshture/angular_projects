package com.cg.rest;

import org.springframework.stereotype.Controller;

@Controller
public class TestController {

}
