package com.cg.repo;

import java.util.List;

import com.cg.entity.Trainee;

public interface TraineeRepo {

	void saveTrainee(Trainee p);
	
	Trainee getTraineeById(int id);
	
	List<Trainee> getAllTrainees();
	
	void deleteTrainee(int i);
	
	void modifyTrainee(Trainee trainee);
}
