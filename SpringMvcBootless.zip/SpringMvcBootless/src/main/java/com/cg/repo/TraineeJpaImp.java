package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;

@Repository
@Transactional
public class TraineeJpaImp implements TraineeRepo {
	
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em ;
	
//	@Transactional(propagation = Propagation.REQUIRED)
	public void saveTrainee(Trainee p) {
		em.persist(p);
	}

//	@Transactional(propagation = Propagation.SUPPORTS)
	public Trainee getTraineeById(int id) {
		return em.find(Trainee.class, id);
	}

//	@Transactional
	public List<Trainee> getAllTrainees() {
		return em.createQuery("from Trainee").getResultList();
	}

//	@Transactional
	public void deleteTrainee(int i) {
		Trainee p = em.find(Trainee.class, i);
		em.remove(p); 
	}

	public void modifyTrainee(Trainee trainee) {
		em.merge(trainee);
	}
}
