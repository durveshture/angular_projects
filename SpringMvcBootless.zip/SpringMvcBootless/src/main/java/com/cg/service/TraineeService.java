package com.cg.service;

import java.util.List;

import com.cg.entity.Trainee;

public interface TraineeService {
	
	public void addTrainee(Trainee trainee);

	public void deleteTrainee(int id);

	public void modifyTrainee(Trainee trainee);

	public Trainee findTraineeById(int id);

	public List<Trainee> findAllTrainee();


}
