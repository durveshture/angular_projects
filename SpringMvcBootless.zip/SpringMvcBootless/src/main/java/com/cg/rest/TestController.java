package com.cg.rest;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeJpaImp;
import com.cg.service.TraineeService;
import com.cg.service.TraineeServiceImpl;

import antlr.collections.List;

@Controller
public class TestController {
	
	java.util.List<Trainee> traineeDb;

	@Autowired
	TraineeService service;
	
	@RequestMapping(path="/login",method=RequestMethod.GET)
	public String login() {
		return "login";
	}
	
	@RequestMapping(value="register")
	public String register(Model model) {
		ArrayList<String> domainList= new ArrayList<String>();
		domainList.add("JAVA");
		domainList.add("DOTNET");
		domainList.add("PYTHON");
		model.addAttribute("domainList", domainList);
		model.addAttribute("trainee", new Trainee());
		return "register";
	}
	
	@RequestMapping(value="menu")
	public String menu() {
		return "menu";
	}
	
	@RequestMapping(value="checklogin")
	public String checkLogin(@RequestParam("username") String username, @RequestParam("password") String password) {
		if(username.equals("admin") && password.equals("1234")) {
			return "menu";
		}
		else {
			return "login";
		}
	}
	
	@RequestMapping(value="addTrainee")
	public String addTrainee(@ModelAttribute("trainee") Trainee trainee, Model model)  {
		 
		service.addTrainee(trainee);
		model.addAttribute("insertMessage", "Trainee added successfully");
		return "register";
	}
	
	@RequestMapping(value="trainees")
	public String retrieveAllTrainees(@ModelAttribute("trainee") Trainee trainee,Model model) {
		traineeDb= new ArrayList<Trainee>();
		traineeDb=service.findAllTrainee();
		model.addAttribute("traineeDb", traineeDb);
		return "alltrainees";
	}
	
	@RequestMapping(value="deletetrainee")
	public String deleteTrainee(@RequestParam("tranId") int tranId,Model model) {
		Trainee trainee= new Trainee();
		trainee=service.findTraineeById(tranId);
		service.deleteTrainee(tranId);
		model.addAttribute("deleteMessage", "successfully deleted record");
		return "deletetrainee";
	}
	
	@RequestMapping(value="preparedelete")
	public String prepareDeleteTrainee() {
		return "deletetrainee";
	}
	
	@RequestMapping(value="prepareretrieve")
	public String prepareRetrieveTrainee() {
		return "fetchtrainee";
	}
	
	@RequestMapping(value="trainee")
	public String retrieveTrainee(@RequestParam("tranId") int tranId,Model model) {
		Trainee trainee= new Trainee();
		trainee=service.findTraineeById(tranId);
		traineeDb= new ArrayList<Trainee>();
		traineeDb.add(trainee);
		model.addAttribute("traineeDb", traineeDb);
		return "alltrainees";
	}
	
	@RequestMapping(value="preparemodifytrainee")
	public String prepareModifyTrainee(Model model) {
		model.addAttribute("trainee",new Trainee());
		return "modifytrainee";
	}
	
	@RequestMapping(value="modifytrainee")
	public String modifyTrainee(@RequestParam("tranId") int tranId,Model model) {
		Trainee trainee= service.findTraineeById(tranId);
		model.addAttribute("trainee",trainee);
		return "modifytrainee";
	}
	
	@RequestMapping(value="modify")
	public String modify(@ModelAttribute("trainee") Trainee trainee,Model model) {
		service.modifyTrainee(trainee);
		model.addAttribute("modifyMessage", "modified successfully");
		return "modifytrainee";
	}
	
}
