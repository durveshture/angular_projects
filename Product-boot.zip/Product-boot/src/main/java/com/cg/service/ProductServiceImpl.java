package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;


@Repository
@Transactional
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepo repo;
	
	

	
	@Transactional(propagation=Propagation.REQUIRED)
	public void saveProduct(Product p) {
		repo.save(p);
	}

	@Transactional(propagation=Propagation.SUPPORTS)
	public Product get(int id) {
		return repo.findById(id).get();
		
	}

    @Transactional
	public Iterable<Product> getAll() {
		return repo.findAll();
	}

	@Override
	@Transactional
	public Product update(Product p, int id) {
		p.setId(id);
		repo.save(p);
		
		return p;
	}

	

//    @Transactional
//	public String deleteProduct(int id) {
//    	Product p1 = em.find(Product.class, id);
//	    em.remove(p1);
//	    return "Delete Successfully";
//	    
//	}

}
