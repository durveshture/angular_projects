package com.cg.anno;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;


@Service("producer")
public class Producer{  // implements ApplicationContextAware {

	@Autowired 
	private ApplicationContext ctx;

	public void process(String type, String to, String msg) {
		Sender sender = (Sender) ctx.getBean(type);
		sender.send(to, msg);
	}

//	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {  //here the obj of applicationContext is passed auto by spring container, we just need to store it inside our bean
//
//		
//		this.ctx = applicationContext;
//	}
}
