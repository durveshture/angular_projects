package com.cg.anno;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("helloObj1")
public class Hello {

	private String greeting;   //class Hello is dependent on class String, so to remove dependency it should be defined in hello.xml as a bean class
	private int number;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public Hello(int number) {
		super();
		System.out.println("inside number const");
		this.number = number;
	}

	public Hello(String greeting, int number) {
		super();
		System.out.println("inside 2 param const");
		this.greeting = greeting;
		this.number = number;
	}

	public Hello() {
	}

	public Hello(String greeting) {
		super();
		System.out.println("inside greeting const");
		this.greeting = greeting;
	}
	

	public String getGreeting() {
		return greeting;
	}

	@Value("Hello Spring")
	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}
}
