package com.cg.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Client {

	private static Client client;

	public static Client getClient() {
		if (client == null)
			client = new Client();

		return client;

	}
}
