package com.cg.ioc;

public class WhatsappSender implements Sender {

	public WhatsappSender() {
		System.out.println("Whatsapp Sender is ready");
	}

	public void send(String to, String msg) {

		System.out.println("Whatsapp" + msg + " sent to " + to);
	}

}
