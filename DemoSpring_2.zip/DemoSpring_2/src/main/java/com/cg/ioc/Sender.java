package com.cg.ioc;

public interface Sender {

	public void send(String to, String msg); 
}
