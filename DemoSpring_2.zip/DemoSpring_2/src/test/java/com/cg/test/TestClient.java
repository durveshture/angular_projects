package com.cg.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Client;

//import com.cg.ioc.Client;

public class TestClient {

	@Test
	public void testClient() {
//		ApplicationContext ctx= new ClassPathXmlApplicationContext("hello.xml");
		ApplicationContext ctx= new ClassPathXmlApplicationContext("annotated.xml");
		Client c1= ctx.getBean(Client.class);  // here instead of getting bean obj by id, we are getting bean by class
		Client c2= ctx.getBean(Client.class);
	
//		assertEquals(c1, c2);
		assertNotEquals(c1, c2);
	}
}
