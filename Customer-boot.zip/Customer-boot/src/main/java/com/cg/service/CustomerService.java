package com.cg.service;

import org.springframework.http.ResponseEntity;

import com.cg.entities.Customer;

public interface CustomerService {

	Customer saveCustomer(Customer customer);

	Customer getCustomerById(int id);

	Iterable<Customer> getAllCustomers();

	String delete(int id);

	Customer updateCustomer(Customer customer, int id);
	
	Customer findByCustomerName(String name);
}
