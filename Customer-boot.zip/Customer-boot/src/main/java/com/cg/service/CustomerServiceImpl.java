package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Customer;
import com.cg.repo.CustomerRepo;

@Repository
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo repo;
	
	@Override
	public Customer saveCustomer(Customer customer) {

		repo.save(customer);
		return customer;
	}

	@Override
	
	public Customer getCustomerById(int id) {
		
		return repo.findById(id).get();
	}

	@Override
	
	public Iterable<Customer> getAllCustomers() {
		
		return repo.findAll();
	}

	@Override
	
	public String delete(int id) {
		repo.deleteById(id);
		return "deleted successfully";
	}

	@Override
	
	public Customer updateCustomer(Customer customer, int id) {
        customer.setCustomerId(id);
		repo.save(customer);
		return customer;
	}

	@Override
	public Customer findByCustomerName(String name) {
		
		return repo.findByCustomerName(name);
	}

}
