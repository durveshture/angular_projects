package com.capgemini.citi.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.bean.TransactionEntries;
import com.capgemini.citi.service.IService;
import com.capgemini.citi.service.ServiceClass;
import com.capgemni.citi.exception.CustomerExists;
import com.capgemni.citi.exception.CustomerNotFoundException;
import com.capgemni.citi.exception.InsuffiecientBalanceException;
import com.capgemni.citi.exception.SenderReceiverSameException;

public class MainUI {

	public static void main(String[] args) throws SQLException, CustomerExists {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		IService service = (ServiceClass) ctx.getBean("service");

		Scanner scan = new Scanner(System.in);
		int choice = 0;
		Customer validatedCustomer;
		boolean isLogOut = false;
		String name;
		String mobile;
		String email;
		String username;
		String password;
		String message = null;

		Customer customer = null;

		System.out.println("Welcome To Dude Wallet");
		while (true) {
			System.out.print("1.Register");
			System.out.println("\n 2.Login");
			System.out.println("\n 3.Exit \n");
			choice = scan.nextInt();
			if (choice == 1) {

				customer = new Customer();
				System.out.println("Enter details:");

				while (true) {
					System.out.println("Enter Name");
					name = scan.next();
					boolean isValid = service.validateName(name);
					if (isValid) {
						customer.setName(name);
						break;
					}

					System.out.println("Name should contain only alphabets & only first letter should be capital");
				}

				while (true) {
					System.out.println("Enter Mobile no:");
					mobile = scan.next();
					boolean isValid = service.validateMobile(mobile);
					if (isValid) {
						customer.setMobileNo(Long.parseLong(mobile));
						break;
					}
					System.out.println("Mobile number should be 10 digits and start with 7/8/9");

				}
				while (true) {
					System.out.println("Enter Email:");
					email = scan.next();
					boolean isValid = service.validateEmail(email);
					if (isValid) {
						customer.setEmail(email);
						break;
					}
					System.out.println("Invalid email");
				}

				while (true) {
					System.out.println("Enter Password");
					password = scan.next();
					boolean isValid = service.validatePassword(password);
					if (true) {
						customer.setPassword(password);
						break;
					}
					System.out.println(
							"Password should be 8 characters, should contain at least one special character, digit and one uppercase letter");
				}

				service.insertCustomer(customer);

				System.out.println("Customer Registered Successfully\n Customer ID " + customer.getCustId());
				System.out.println(customer.toString());
			}

			else if (choice == 2) {

			
				while (true) {
					System.out.println("Enter mob no");
					mobile = scan.next();
					boolean isValid = service.validateMobile(mobile);
					if (isValid)
						break;
				}

				while (true) {
					System.out.println("Enter Password");
					password = scan.next();
					boolean isValid = service.validatePassword(password);
					if (true)
						break;
					System.out.println(
							"Password should be 8 characters, should contain at least one special character, digit and one uppercase letter");
				}

				validatedCustomer = service.login(Long.parseLong(mobile), password);

				if (validatedCustomer != null) {
					System.out.println("login successful");
					while (true) {

						System.out.println("Menu");
						System.out.println(
								"1.Show Balance\n 2.Deposit\n 3.Withdraw\n 4.Fund Transfer\n 5.Print Transaction\n 6.log out");
						choice = scan.nextInt();
						switch (choice) {
						case 1: {
							System.out.println("Account Balance is:" + service.showBalance(validatedCustomer));
							break;
						}
						case 2: {
							System.out.println("Enter amount to deposit:");
							double amount = scan.nextDouble();
							try {
								message = service.deposit(amount, validatedCustomer);
							} catch (CustomerNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							System.out.println(message);
							break;
						}
						case 3: {
							System.out.println("Enter the amount to be withdrawn");
							double amount = scan.nextDouble();

							try {
								message = service.withdraw(amount, validatedCustomer);
							} catch (InsuffiecientBalanceException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							System.out.println(message);
							break;
						}
						case 4: {
							System.out.println("Enter the Mobile no of the receiver:");
							long receiverMobileNo = scan.nextLong();
							Customer validateReceiver = service.checkCredentials(receiverMobileNo);
							if (validateReceiver != null) {
								System.out.println("Enter the Amount to transfer");
								double amount = scan.nextDouble();
								try {
									service.fundTransfer(validatedCustomer, validateReceiver, amount);
								} catch (InsuffiecientBalanceException e) {
									e.printStackTrace();
								} catch (SenderReceiverSameException e) {
									e.printStackTrace();
								}
								System.out.println("Amount Transferred Successfull");
							}

							break;
						}
						case 5: {
							List<TransactionEntries> l = service.printTransaction(validatedCustomer.getMobileNo());
							for (TransactionEntries transactionEntries : l) {
								System.out.println(transactionEntries);

							}
							break;
						}
						case 6:
							isLogOut = true;
							break;

						default:
							break;
						}
						if (isLogOut == true) {
							isLogOut = false;
							break;
						} else
							continue;

					}

				}

			} else {
				System.exit(0);
			}

		}

	}

}
