package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Service("service")
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo repo;
	
	public Product saveProduct(Product product) {
		return repo.saveProduct(product);
	}

	public List<Product> getAll() {
		return repo.getAllProducts();
	}

}
