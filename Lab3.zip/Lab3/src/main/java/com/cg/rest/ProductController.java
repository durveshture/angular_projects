package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;
import com.cg.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService service;
	
	@PostMapping(path="/add")
	public Product addProduct(@ModelAttribute("product") Product product,Model model) {
		product= service.saveProduct(product);
		model.addAttribute("insertMsg", "product added successfully");
		return product;
	}
	
	@GetMapping(path="/menu")
	public ModelAndView showMenu() {
		return new ModelAndView("home","product",new Product());
	}
	
	@GetMapping(path="/products", produces = "application/json")
	public List<Product> showAllProducts(){
		return service.getAll();
	}
	
	@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
		org.springframework.web.util.NestedServletException.class,
		org.springframework.orm.jpa.JpaSystemException.class,
		javax.persistence.PersistenceException.class,
		org.hibernate.exception.ConstraintViolationException.class
	})
	
	public ModelAndView showError()
	{
		return new ModelAndView("error");
	}
}
