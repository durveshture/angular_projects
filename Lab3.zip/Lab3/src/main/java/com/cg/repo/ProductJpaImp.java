package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository("repo")
public class ProductJpaImp implements ProductRepo {
	
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em ;
	
	@Transactional(propagation=Propagation.REQUIRED)
	public Product saveProduct(Product product) {
		em.persist(product);
		return product;
	}

	@Transactional(readOnly=true)
	public List<Product> getAllProducts() {
		return em.createQuery("from Product").getResultList();
	}
}
