package com.capgemini.xyz.test;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.service.CustomerService;
import com.capgemini.xyz.service.CustomerServiceInterface;

public class LoginTest {

	CustomerServiceInterface service = null;

	@Before
	public void setUp() throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		service = (CustomerServiceInterface) ctx.getBean("service");
	}

	// right inputs
	@Test
	public void checkLogin() {
		try {
			Customer cust = service.checkUser("8286703935", "password");
			assertNotNull(cust);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	// wrong inputs
	// should print no user in console
	@Test
	public void checkLogin2() {
		try {
			Customer cust2 = service.checkUser("23123123", "asdasd");
			assertNotNull(cust2);
		} catch (CustomerNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
