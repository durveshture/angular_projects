package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.cg.entities.Product;
import com.cg.entities.ProductRepo;

@SpringBootApplication
//@EntityScan("com.cg.entities")
public class DataBootApplication implements CommandLineRunner {

	@Autowired
	private ProductRepo repo;
	
	public static void main(String[] args) {
		SpringApplication.run(DataBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		Product p= new Product();
//		p.setName("lenovo");
//		p.setPrice(11000);
//		p.setId(100);
//		repo.save(p);
		
		Product p = repo.findById(100).get();
		System.out.println(p);
		
		
	}

}
