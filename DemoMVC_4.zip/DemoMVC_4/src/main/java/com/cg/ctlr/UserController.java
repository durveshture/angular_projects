package com.cg.ctlr;

import java.util.ArrayList;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Scope("session")
@Controller
@RequestMapping(value = "user")
public class UserController {
	
	Login log;
	ArrayList<String> cityList;
	ArrayList<String> skillList;

	@RequestMapping(value = "showLogin")
	public String prepareLogin(Model model) {
		System.out.println("In prepareLogin() method");
		log = new Login();
		// log.setUserName("admin@gmail.com");
		model.addAttribute("login", log);
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(
		@ModelAttribute("login") @Valid Login login,BindingResult result, Model m ) {
//	public String checkLogin(@RequestParam("userName") String user, @RequestParam("password") String pass, Model m ) {
		// Logic to validate userName and password against database
		if(result.hasErrors()) {
			return "login";
		}else {
			if (login.getUserName().equals("durvesh") && login.getPassword().equals("ture")) {
				return "loginSuccess";
			} else {
				m.addAttribute("errorMsg", "invalid username or password");
				return "login";
			}
		}
	}

	@RequestMapping(value = "showRegister")
	public String prepareRegister(Model model) {
cityList =new ArrayList<String>();
		
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Delhi");
		
		skillList =new ArrayList<String>();
		
		skillList.add("Java");
		skillList.add("Struts");
		skillList.add("Spring");
		skillList.add("Hibernate");
		
		model.addAttribute("cityList",cityList);
		model.addAttribute("skillList",skillList);
		model.addAttribute("user", new User());
		return "register";
	}

	@RequestMapping(value = "checkRegister")
	public String checkRegister(@ModelAttribute
			("user")
	@Valid User user,BindingResult result,
	Model model) {
		 if(result.hasErrors())
		 {
			 System.out.println("Error");
			 model.addAttribute("cityList",cityList);
    		 model.addAttribute("skillList",skillList);

			 return "register";
		 }
		 else
		 {
          model.addAttribute("user",user);  
          System.out.println("Valid  dd");
	  	  return "registerSuccess";	
		 }
		
	}

}
