package com.cg.testlab1_3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.introlab1_2.EmployeeXml;
import com.cg.introlab1_3.SBUXml;

public class TestEmployee {

	public static void main(String[] args) {
		ApplicationContext ctx= new ClassPathXmlApplicationContext("employeeConfig3.xml");
		SBUXml SBU= (SBUXml) ctx.getBean("sbu");
		System.out.println(SBU.getEmpList());

	}
}
