/**
 * 
 */
package com.cg.testlab1_4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.introlab1_4.Employee;

/**
 * @author Aditya Sinha
 *
 */
public class EmployeeClient {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeeConfig4.xml");
		Employee tempEmployee;
		Employee emp = (Employee) ctx.getBean("employee");
		Employee emp1 = (Employee) ctx.getBean("employee1");
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(emp);
		employeeList.add(emp1);

		Scanner sc = new Scanner(System.in);
		for (;;) {
			System.out.println("INPUT");
			System.out.println("Enter Employee ID:");
			int empId = sc.nextInt();

			System.out.println("employee details:");
			for (Object employee : employeeList) {
				tempEmployee = (Employee) employee;
				if (tempEmployee.getID() == empId) {
					System.out.println(employee);
				}
			}
		}
	}

}
