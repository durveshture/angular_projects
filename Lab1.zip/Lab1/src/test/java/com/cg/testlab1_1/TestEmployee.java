package com.cg.testlab1_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.introlab1_1.EmployeeXml;

public class TestEmployee {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new ClassPathXmlApplicationContext("employeeConfig.xml");
		EmployeeXml emp= (EmployeeXml) ctx.getBean("employee");
		System.out.println(emp);
	}
}
