package com.cg.testlab1_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.introlab1_1.EmployeeAnnotation;


public class TestEmployeeAnno {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeeConfigAnnotation.xml");
		EmployeeAnnotation emp = (EmployeeAnnotation) ctx.getBean("employeeAnno");
		System.out.println(emp);
	}
}
