package com.cg.introlab1_2;

public class EmployeeXml {

	int employeeId;
	String employeeName;
	double salary;
	SBUXml businessUnit;
	
	
	public EmployeeXml() {
	
	}
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public SBUXml getSbuDetails() {
		return businessUnit;
	}


	public void setBusinessUnit(SBUXml businessUnit) {
		this.businessUnit = businessUnit;
	}


	@Override
	public String toString() {
		return "EmployeeXml [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", businessUnit=" + businessUnit + "]";
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
