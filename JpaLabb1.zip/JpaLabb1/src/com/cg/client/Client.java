package com.cg.client;

import java.util.Scanner;

import com.cg.entities.Author;
import com.cg.service.AuthorService;
import com.cg.service.AuthorServiceImpl;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static String firstName;
	static String middleName;
	static String lastName;
	static int authorId;
	static double phoneNo;
	static AuthorService service;
	static Author author;

	

	public static Author setAuthor() {
		author = new Author();
		System.out.println("Enter author first name:");
		firstName = sc.next();
		author.setFirstName(firstName);
		System.out.println("Enter author middle name:");
		middleName = sc.next();
		author.setMiddleName(middleName);
		System.out.println("Enter author last name:");
		lastName = sc.next();
		author.setLastName(lastName);
		System.out.println("Enter author phone no:");
		phoneNo = sc.nextDouble();
		author.setPhoneNo(phoneNo);
		author = service.addAuthor(author);
		return author;

	}

	public static void main(String[] args) {

		int choice;
		service = new AuthorServiceImpl();

		for (;;) {
			System.out.println("Which operation you want to perform?");
			System.out.println("1) Add author");
			System.out.println("2) update author");
			System.out.println("3) delete student");
			System.out.println("4) fetch author");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				author = setAuthor();
				System.out.println("Author inserted successfully. id is: "
						+ author.getAuthorId());
				break;

			case 2:
				System.out.println("Enter id of author to update");
				authorId = sc.nextInt();
				author = service.getAuthorById(authorId);
				author=setAuthor();
				service.updateAuthor(author);
				System.out.println("author successfully updated");
				break;

			case 3:
				System.out.println("Enter id of author to delete");
				authorId = sc.nextInt();
				author = service.getAuthorById(authorId);
				service.removeAuthor(author);
				System.out.println("author successfully deleted");
				break;

			case 4:
				System.out.println("Enter id of author to be fetched");
				authorId = sc.nextInt();
				author = service.getAuthorById(authorId);
				System.out.println(author);
				break;
				
			default: System.out.println("Enter valid choice");	
			}
		}
	}
}
