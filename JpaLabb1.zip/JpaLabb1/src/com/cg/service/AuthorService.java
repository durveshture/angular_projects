package com.cg.service;

import com.cg.entities.Author;

public interface AuthorService {

	public Author addAuthor(Author author);

	public void removeAuthor(Author author);

	public void updateAuthor(Author author);

	public Author getAuthorById(int id);

}
