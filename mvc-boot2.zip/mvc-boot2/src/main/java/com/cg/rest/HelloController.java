package com.cg.rest;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	String nameCopy;
	
	@GetMapping("/hola/{name}")
	public String sayHello(@PathVariable("name") String name) {
		this.nameCopy=name;
		return "hello "+name+", Welcome to Spring Boot";
	}
	
	@GetMapping("/bye")
	public String sayGoodBye(@RequestParam("name") String name) {
		return "Bye "+name+",  Visit again";
	}
}
