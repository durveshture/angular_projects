package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;
import com.cg.dao.ClassDao;
import com.cg.dao.GenerateDaoObj;
import com.cg.dao.InterfaceDao;

@Service("is")
//@Scope("singleton")
public class ClassService implements InterfaceService {

//	 static ApplicationContext ctx;
	@Autowired
	InterfaceDao idao;  //= new ClassDao();
	
//	@Autowired
//	public ClassService(InterfaceDao idao) {
//		this.idao=idao;
//	}
//	static{
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
//	}
//	
//	public ClassService() {
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
//		idao= (InterfaceDao) ctx.getBean("dao");
//	}
	
//	public void prepareThings() {
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
//		idao= (InterfaceDao) ctx.getBean("dao");
//		idao= GenerateDaoObj.getDao();
//	}

	@Override
	public void initializeDao(ApplicationContext ctx) {
//		idao= (InterfaceDao) ctx.getBean("dao");
//		idao.initDao(ctx);
	}
	
	public boolean validateName(String name) {
//		prepareThings();
		if (name.matches(userNamePattern)) { // user name regex validation
			return true;
		} else
			return false;
	}

	
	public boolean validateEmail(String email) {
		if (email.matches(emailPattern)) { // email regex validation
			return true;
		} else
			return false;
	}

	
	public boolean validateMobNo(String mobNo) {
		if (mobNo.matches(mobNoPattern)) { // mobile no regex validation
			return true;
		} else
			return false;
	}

	
	public String deposit(Customer customer, double amount)
			throws NegativeAmountException {
		return (idao.deposit(customer, amount)); // calling deposit method of
													// classDao

	}

	
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException {
		return (idao.withdraw(customer, amount)); // calling withdraw method of
													// classDao

	}

	
	public Customer login(long mobNo, String password) {
//		prepareThings();
		
		return (idao.login(mobNo, password)); // calling login method of
												// classDao
	}

	
	public boolean validatePassword(String password) {
		if (password.matches(paswordPattern)) { // password regex validation
			return true;
		} else
			return false;
	}

	
	public String insertCustomer(Customer customer) {
		return (idao.insertCustomer(customer)); // calling insertCustomer method
												// of
		// classDao

	}

	
	public double showBalance(Customer customer) {
		return idao.showBalance(customer); // calling showBalance method of
											// classDao
	}

	


	
	public Customer checkUser(long receiverMobNo) {
		return (idao.checkUser(receiverMobNo)); // calling checkUser method of
												// classDao
	}

	
	public void printTransaction(long mobNo) {
		idao.printTransaction(mobNo); // calling printTransaction method of
										// classDao
	}

	
	public boolean validateAmount(String amount) {
		if (amount.matches(amountPattern)) { // user name regex validation
			return true;
		} else
			return false;
	}


	public String fundTransfer(Customer validatedUser, Customer validatedReceiver, double parseDouble) throws SenderReceiverSameException, LowBalanceException, NegativeAmountException {
		return (idao.fundTransfer(validatedUser, validatedReceiver, parseDouble)); // calling
		// fundTransfer
		// method of
		// classDao
	}

	

}
