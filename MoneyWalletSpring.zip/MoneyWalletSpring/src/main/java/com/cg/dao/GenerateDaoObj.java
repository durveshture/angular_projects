package com.cg.dao;

public class GenerateDaoObj {

	private static ClassDao dao;

	public static ClassDao getDao() {
		if (dao == null)
			dao = new ClassDao();

		return dao;
	}
}
