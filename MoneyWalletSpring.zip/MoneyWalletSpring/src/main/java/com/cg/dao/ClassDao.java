package com.cg.dao;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.*;

//import java.util.ArrayList;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;


@Repository("idao")
@Scope("singleton")
public class ClassDao implements InterfaceDao,ApplicationContextAware {

	Map<Long, Customer> customerMap = new HashMap<Long, Customer>();
	ArrayList<Transaction> tranArray = new ArrayList<Transaction>();
//	@Autowired
	Transaction tran;
	String whatToReturn = null;
	
	@Autowired
	ApplicationContext ctx;

	public ClassDao() {
//		ctx= new ClassPathXmlApplicationContext("annotated.xml");
	}
	
	@Override
	public void initDao(ApplicationContext ctx) {
//		this.ctx=ctx;
		
	}
	
	
	
//	public void prepareThings() {
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
//	}
//	
	
	// Map<Long,String> loginCustomer= new HashMap<>();
	// ArrayList<Customer> database= new ArrayList<>();

	// deposit money in current customer's mobile no account


	// withdraw money in current customer's mobile no account
	
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException {

		if (amount > customer.getBalance()) {

			throw new LowBalanceException("Your balance is low");

		} else {
			// customerMap.get(customer.getMobileNo()).setBalance(
			// customerMap.get(customer.getMobileNo()).getBalance()
			// - amount);
			customer.setBalance(customer.getBalance() - amount);
//			tran = new Transaction("debit", amount, customer.getBalance(),
//					customer.getMobileNo());
//			tranArray.add(tran);
			tran= (Transaction) ctx.getBean("tran");
			tran.setType("debit");
			tran.setAmount(amount);
			tran.setBalance(customer.getBalance());
			tran.setMobNo(customer.getMobileNo());
			tranArray.add(tran);
			
			whatToReturn = "Rs " + amount + " withdrawn successfully at "
					+ LocalDateTime.now() + " for mobile no: "
					+ customer.getMobileNo() + "\n Your updated balance is: "
					+ showBalance(customer);
			return whatToReturn;
		}
		// tran = new Transaction("debit", amount, customerMap.get(
		// customer.getMobileNo()).getBalance(), customerMap.get(
		// customer.getMobileNo()).getMobileNo());

	}

	// checking if the user inputted mobNo and password exists in the map
	
	public Customer login(long mobNo, String password) {
		
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
		for (Long key : customerMap.keySet()) {
			if (key == mobNo
					&& customerMap.get(key).getPassword().equals(password)) {
				return customerMap.get(key);
			}
		}
		return null;
	}

	// inserting the customer obj in the map
	
	public String insertCustomer(Customer customer) {

		
		customerMap.put(customer.getMobileNo(), customer);
		whatToReturn = "Registration successfull! your username is your mobile number: "
				+ customer.getMobileNo();
		return whatToReturn;
	}

	// retrieving balance using current customer's mobile no
	
	public double showBalance(Customer customer) {
		// return customerMap.get(customer.getMobileNo()).getBalance();
		return customer.getBalance();

	}

	// transfer amount from one customer obj to other
	
	public String fundTransfer(Customer senderCustomer,
			Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException {
		if (senderCustomer.getMobileNo() == receiverCustomer.getMobileNo()) {

			throw new SenderReceiverSameException("Cannot send to yourself");

		} else {
			withdraw(senderCustomer, amount); // withdrawing amount from
												// sender's
												// wallet
			deposit(receiverCustomer, amount); // depositing amount to
												// receiver's
												// wallet
			whatToReturn = amount + " Rs transferred to mobile number: "
					+ receiverCustomer.getMobileNo()
					+ "\n Your updated balance is: "
					+ showBalance(senderCustomer);
			return whatToReturn;
		}
	}


	public Customer checkUser(long receiverMobNo) { // finding the user inputted
													// receiverMobNo in the map
//		ctx = new ClassPathXmlApplicationContext("annotated.xml");
		for (Long key : customerMap.keySet()) {
			if (receiverMobNo == customerMap.get(key).getMobileNo()) {
				return customerMap.get(key);
			}
		}
		return null;
	}

	
	public void printTransaction(long mobNo) {

		if (tranArray.isEmpty()) {
			System.out.println("No transactions performed yet!!");
		}
		for (Transaction t : tranArray) {
			if (t.getMobNo() == mobNo) {
				System.out.println(t.toString());
			}
			// System.out.println(t);
		}
	}

	public String deposit(Customer customer, double amount) throws NegativeAmountException {
		if (amount <= 0) {

			whatToReturn = null;
			throw new NegativeAmountException(
					"Please enter amount greater than 0");

		} else {

			// customerMap.get(customer.getMobileNo()).setBalance(
			// customerMap.get(customer.getMobileNo()).getBalance()
			// + amount);
			customer.setBalance(customer.getBalance() + amount);
			// tran = new Transaction("credit", amount, customerMap.get(
			// customer.getMobileNo()).getBalance(), customerMap.get(
			// customer.getMobileNo()).getMobileNo());
//			tran = new Transaction("credit", amount, customer.getBalance(),
//					customer.getMobileNo());
//			tranArray.add(tran);
			
			tran= (Transaction) ctx.getBean("tran");
			tran.setType("credit");
			tran.setAmount(amount);
			tran.setBalance(customer.getBalance());
			tran.setMobNo(customer.getMobileNo());
			tranArray.add(tran);
			
			whatToReturn = "Rs " + amount + " deposited successfully at "
					+ LocalDateTime.now() + " for mobile no: "
					+ customer.getMobileNo() + "\n Your updated balance is: "
					+ showBalance(customer);
			return whatToReturn;
		}
		
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

		this.ctx=applicationContext;
	}


	
}
