package com.cg.ExceptionClass;

public class CustomerExistsException extends Exception {

	public CustomerExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
