package com.cg.jpastart.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.jpastart.entities.Department;

public class TestEmpDept {

	private EntityManager mgr;
	
	@BeforeClass
	public void init(){
		EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
		mgr= factory.createEntityManager();
	}
	
	@Before
	public void start(){
		mgr.getTransaction().commit();
	}
	
	@Test
	public void testFetch(){
		Department dept= mgr.find(Department.class, 10);
		System.out.println("Department: "+dept.getName());
		System.out.println(dept.getEmployees());
	}
	
	@After
	public void stop(){
		mgr.getTransaction().commit();
	}
	
	@AfterClass
	public void flush(){
		mgr.close();
	}
}
