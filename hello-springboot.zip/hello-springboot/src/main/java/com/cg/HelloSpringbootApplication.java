package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
public class HelloSpringbootApplication implements CommandLineRunner {

	@Autowired
	private ApplicationContext ctx;
	
	public static void main(String[] args) {
		SpringApplication.run(HelloSpringbootApplication.class, args);
	}
	
	public void run(String... args) {
		System.out.println("Hello world in main class");
		Hello h= ctx.getBean(Hello.class);
		System.out.println(h);
	}

}
