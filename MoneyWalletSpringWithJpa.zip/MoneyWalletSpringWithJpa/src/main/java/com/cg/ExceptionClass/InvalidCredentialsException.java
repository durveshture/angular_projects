package com.cg.ExceptionClass;

public class InvalidCredentialsException extends Exception {

	public InvalidCredentialsException() {

	}

	public InvalidCredentialsException(String message) {
		super(message);
	}

}
