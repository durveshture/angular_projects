package com.cg.ui;

import java.util.Scanner;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ExceptionClass.CustomerExistsException;
import com.cg.ExceptionClass.InvalidCredentialsException;
import com.cg.ExceptionClass.InvalidReceiverException;
import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;
import com.cg.service.ClassService;
import com.cg.service.InterfaceService;

public class Main { // implements ApplicationContextAware {
	
	
	public static void main(String[] args) {

		 InterfaceService is;
		// @Autowired
		 ApplicationContext ctx;
		ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		is=(InterfaceService) ctx.getBean("service");
		Scanner sc = new Scanner(System.in);
		String choice, password, currentLoginPassword, email, mobNo, currentLoginMobNo;
		boolean isValid, isLogout = false;
		Customer validatedUser, validatedReceiver, customerExists;
		double custId = 1;
		String amount, transferAmount;
		String messageToDisplay;
		 										// object
		Customer customer; // declaring customer bean object

		for (;;) {
			// Home page
			System.out.println("Weclcome to DTM wallet");
			System.out.println("1) Register");
			System.out.println("2) Login");
			choice = sc.next();
			if (choice.equals("1")) {
				 customer = new Customer(); // creating a new customer obj if
				// user selects register option
//				customer = ctx.getBean(Customer.class);
				while (true) {
					// Registration page
					System.out.println("Enter Name: "); // input name and
														// validate regex
					String name = sc.next();
					isValid = is.validateName(name);
					if (isValid) {
						customer.setName(name); // if name is valid,populate the
												// customer obj
						break;
					}
					System.out.println("Name should contain only alphabets & only first letter should be capital");
				}
				while (true) {
					System.out.println("Enter Mobile Number: "); // input mob no
																	// and
																	// validate

					mobNo = sc.next();
					isValid = is.validateMobNo(mobNo);
					if (isValid) {
						customer.setMobileNo(Long.parseLong(mobNo)); // if mobno
																		// is
																		// valid,populate
																		// the
																		// customer
																		// obj
						break;
					}
					System.out.println("Mobile number should be 10 digits and start with 7/8/9");
				}
				while (true) {
					System.out.println("Enter password: "); // input password
															// and validate

					password = sc.next();
					isValid = is.validatePassword(password);
					if (isValid) {
						customer.setPassword(password); // if password is
														// valid,populate the
														// customer obj
						break;
					}
					System.out.println(
							"Password should be 8 characters, should contain at least one special character, digit and one uppercase letter");
				}
				while (true) {
					System.out.println("Enter Email Id: "); // input email and
															// validate
					email = sc.next();
					isValid = is.validateEmail(email);
					if (isValid) {
						customer.setEmail(email); // if email is valid,populate
													// the customer obj
						break;
					}
					System.out.println("Invalid email");
				}

				customerExists = is.checkUser(Long.parseLong(mobNo));
				if (customerExists != null) {
					try {
						throw new CustomerExistsException("There is already an account for this mobile number");
					} catch (CustomerExistsException e) {
						e.printStackTrace();
					}
				}
				customer.setCustId(custId);
				custId++;
				is.insertCustomer(customer);

			} else {
				// login page
				while (true) {
					System.out.println("Enter Mobile Number: "); // input mob no
																	// and
																	// validate

					currentLoginMobNo = sc.next();
					isValid = is.validateMobNo(currentLoginMobNo);
					if (isValid) {
						break;
					}
				}
				while (true) {
					System.out.println("Enter password: "); // input password
															// and validate

					currentLoginPassword = sc.next();
					isValid = is.validatePassword(currentLoginPassword);
					if (isValid) {
						break;
					}
				}
				validatedUser = is.login(Long.parseLong(currentLoginMobNo), // user
																			// login
																			// validation
						currentLoginPassword);

				if (validatedUser != null) { // if mobno and password is
												// correct,login successfull and
												// welcome page is displayed
					// Menu(welcome) page
					// Menu page has total 6 functionalities
					System.out.println("Welcome");
					while (true) {
						System.out.println("1) Show Balance");
						System.out.println("2) Deposit");
						System.out.println("3) Withdraw");
						System.out.println("4) Fund Transfer");
						System.out.println("5) Print Transactions");
						System.out.println("6) Log out");
						choice = sc.next();

						switch (choice) {

						case "1": // to show balance of current login person
							System.out.println("Your balance is: " + is.showBalance(validatedUser));
							break;

						case "2": // to deposit money of curent login customer
							try {
								while (true) {
									System.out.println("How much amount you want to deposit?"); // input
																								// password
									// and validate

									amount = sc.next();
									isValid = is.validateAmount(amount);
									if (isValid) {
										break;
									}
									System.out.println("Amount should be minimum 1 and maximum 999999999");
								}

								messageToDisplay = is.deposit(validatedUser, Double.parseDouble(amount));
								System.out.println(messageToDisplay);
							} catch (NumberFormatException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (NegativeAmountException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							// System.out.println("Your updated balance is: "
							// + is.showBalance(Long
							// .parseLong(currentLoginMobNo)));
							break;

						case "3": // to withdraw money of current login customer
							try {
								while (true) {
									System.out.println("How much amount you want to deposit?"); // input
																								// password
									// and validate

									amount = sc.next();
									isValid = is.validateAmount(amount);
									if (isValid) {
										break;
									}
									System.out.println("Amount should be minimum 1 and maximum 999999999");
								}

								messageToDisplay = is.withdraw(validatedUser, Double.parseDouble(amount));
								System.out.println(messageToDisplay);
							} catch (NumberFormatException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (LowBalanceException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							// System.out.println("Your updated balance is: "
							// + is.showBalance(Long
							// .parseLong(currentLoginMobNo)));
							break;

						case "4": // to transfer money from one customer object
									// to other
							System.out.println("Enter the mobile number of receiver: ");
							long receiverMobNo = sc.nextLong();
							validatedReceiver = is.checkUser(receiverMobNo);
							if (validatedReceiver != null) {
								try {
									while (true) {
										System.out.println("How much amount you want to deposit?"); // input
																									// password
										// and validate

										transferAmount = sc.next();
										isValid = is.validateAmount(transferAmount);
										if (isValid) {
											break;
										}
										System.out.println("Amount should be minimum 1 and maximum 999999999");
									}

									messageToDisplay = is.fundTransfer(validatedUser, validatedReceiver,
											Double.parseDouble(transferAmount));
									System.out.println(messageToDisplay);
								} catch (NumberFormatException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (SenderReceiverSameException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (LowBalanceException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (NegativeAmountException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							} else {
								try {
									throw new InvalidReceiverException("Invalid mobile number of receiver");
								} catch (InvalidReceiverException e) {
									e.printStackTrace();
								}
							}
							break;

						case "5": // to print transaction statement of current
									// login customer
							is.printTransaction(Long.parseLong(currentLoginMobNo));
							break;

						case "6": // to logout
							isLogout = true;
							break;

						default: // if user selects option which is not in menu,
									// throw exception
							System.out.println("Enter a valid choice");
						}
						if (isLogout == true) { // if user selects logout
												// option, break the infinite
												// while loop
							isLogout = false;
							break;
						} else {
							continue;
						}
					}

				} else {
					try {
						throw new InvalidCredentialsException("Invalid username or password"); // if username
																								// or
																								// password
																								// is
																								// incorrect
																								// during
																								// login,
																								// throw an
																								// exception
					} catch (InvalidCredentialsException e) {
						e.printStackTrace();
					}
				}

			}
		}
	}

}