package com.capgemini.xyz.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.TransactionDatas;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.InsufficientBalanceException;

@Repository("customerDAO")
public class CustomerSpringCoreDao implements ICustomerDAO,ApplicationContextAware {

	
	List<Customer> database;
	List<TransactionDatas> transactionDB;
	long cid = CID;
	int tid = TID;
	
	@Autowired
	private ApplicationContext context;

	public CustomerSpringCoreDao() {
		database = new ArrayList();
		transactionDB = new ArrayList();
	}

	@Override
	public Customer createCustomer(Customer customer) throws CustomerExists {
		// check if user exists
		// count should be 0
		long count = database.stream().filter(x -> x.getMobileNumber().equals(customer.getMobileNumber())).count();
		if (count < 1) {
			// add customer
			customer.setCustomerId(++cid);
			database.add(customer);

			// store its first transaction
			TransactionDatas recordTrans = (TransactionDatas) context.getBean(TransactionDatas.class);
			recordTrans.setTid(++tid);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("CR");
			recordTrans.setAmount(customer.getBalance());
			recordTrans.setBalance(customer.getBalance());
			transactionDB.add(recordTrans);
			return customer;
		} else
			// if customer exists then throw error
			throw new CustomerExists("User Already Exists");
	}

	@Override
	public String withDraw(Customer customer, double amount) throws InsufficientBalanceException {
		// withdraw logic
		// minimum balance should be atleast Rs.100
		if (amount <= customer.getBalance() - 100) {
			customer.setBalance(customer.getBalance() - amount);

			// store transaction history
			TransactionDatas recordTrans = (TransactionDatas) context.getBean(TransactionDatas.class);
			recordTrans.setTid(++tid);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("DB");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(customer.getBalance());
			transactionDB.add(recordTrans);
			// return success data in string format
			return "Rs." + amount + " debited from account " + customer.getCustomerId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} else
			// throws exception if balance is below 1000
			// will be cached by service class
			throw new InsufficientBalanceException("You Have Insufficient Amount.");
	}

	@Override
	public String deposit(Customer customer, double amount) throws CustomerNotFoundException {
		try {
			customer.setBalance(customer.getBalance() + amount);
			// store transaction history
			TransactionDatas recordTrans = (TransactionDatas) context.getBean(TransactionDatas.class);
			recordTrans.setTid(++tid);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("CR");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(customer.getBalance());
			transactionDB.add(recordTrans);
			// return success data in string format
			return "Rs." + amount + " credited on account " + customer.getCustomerId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} catch (Exception e) {
			// if user not found
			throw new CustomerNotFoundException("Invalid Mobile Number");
		}
	}

	@Override
	public Customer checkUser(String username, String password) throws CustomerNotFoundException {

		// to login
		// check username which is mobile number and password
		try {
			Customer customer = database.stream()
					.filter(x -> x.getMobileNumber().equals(username) && x.getPassword().equals(password)).findFirst()
					.get();
			return customer;
		} catch (Exception e) {

			// if invalid credentials
			throw new CustomerNotFoundException("No User Found");
		}
	}

	@Override
	public List<TransactionDatas> printTransaction(Customer customer) {
		// create a list to return transaction history of a user
		List<TransactionDatas> summaryList = new ArrayList<TransactionDatas>();

		// find summary of the user
		summaryList = transactionDB
						.stream()
						.filter(x -> x.getMobileNo().equals(customer.getMobileNumber()))
						.collect(Collectors.toList());

		return summaryList;
	}

	@Override
	public Customer isValidUser(String mobileNumber) throws CustomerNotFoundException {

		try {
			// find customer
			Customer customer = database.stream().filter(x -> x.getMobileNumber().equals(mobileNumber)).findFirst()
					.get();
			return customer;
		} catch (Exception e) {
			// if user not found
			throw new CustomerNotFoundException("Invalid Mobile Number");
		}
	}

	@Override
	public double checkBalance(Customer customer) {
		return customer.getBalance();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
		
	}

}
