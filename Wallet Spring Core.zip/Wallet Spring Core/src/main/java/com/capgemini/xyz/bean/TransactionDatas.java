package com.capgemini.xyz.bean;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("recordTrans")
@Scope("prototype")
public class TransactionDatas {

	private int tid;
	private String mobileNo;
	private String type;
	private double amount, balance;
	
	// getters setters
	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "tid=" + tid + ", mobileNo=" + mobileNo
				+ ", type=" + type + ", amount=" + amount + ", balance="
				+ balance + "\n";
	}
}
